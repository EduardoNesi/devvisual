using System;

namespace atividade
{
    class Exer01{

        public static void Renderizar(){


        Console.WriteLine("Digite a altura: ");
            int altura = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Digite a largura: ");
            int largura = Convert.ToInt32(Console.ReadLine());

            int area = altura * largura;
            Console.WriteLine("A área é " + area);
        } 
    }    
}