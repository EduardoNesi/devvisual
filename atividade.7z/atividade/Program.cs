﻿using System;

namespace atividade
{
    class Program
    {
        static void Main(string[] args)
        {
            Exer04.Renderizar();
        }
    }
}
